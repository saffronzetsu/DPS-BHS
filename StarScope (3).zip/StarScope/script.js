// Mission Modal Logic
function openMission(card) {
  const title = card.querySelector("h3").textContent;
  const text = card.querySelector("p").textContent;

  document.getElementById("modalTitle").textContent = title;
  document.getElementById("modalText").textContent = text;
  document.getElementById("missionModal").style.display = "flex";
}

function closeModal() {
  document.getElementById("missionModal").style.display = "none";
}

// Tour Data
const tours = {
  "dark-sky": {
    title: "Dark-Sky Discovery",
    location: "StarScope Dark-Sky Reserve",
    duration: "2.5 Hours",
    timings: "8:00 PM – 10:30 PM (Weekends)",
    price: "₹1,499 per person",
    highlights: [
      "Laser-guided constellation tour",
      "Deep-sky viewing with 10” Dobsonian telescope",
      "Live storytelling of mythological star legends",
      "Complimentary hot chocolate & cozy seating"
    ],
    idealFor: "Beginners, Couples, Nature Enthusiasts",
    bonus: "Free Milky Way poster (digital copy)"
  },
  "mountain-milky": {
    title: "Mountain Milky Way",
    location: "Himalayan Viewpoint Observatory",
    duration: "4 Hours",
    timings: "7:30 PM – 11:30 PM (Clear sky nights only)",
    price: "₹3,499 per person",
    highlights: [
      "High-altitude telescope session",
      "Stunning views of the Milky Way core",
      "Photography-friendly setup",
      "Interactive astrophysics Q&A with expert guides"
    ],
    idealFor: "Photography Buffs, Adventure Seekers",
    bonus: "Free 10-minute personal photo under the stars"
  },
  "family-night": {
    title: "Family Night Under Stars",
    location: "StarScope City Fringe Observatory",
    duration: "2 Hours",
    timings: "6:30 PM – 8:30 PM (Fri–Sun)",
    price: "₹999/adult, ₹599/child (under 12)",
    highlights: [
      "Interactive stargazing games for kids",
      "Kid-friendly telescope viewing",
      "Storytelling session: “Stars & Space Myths”",
      "Family group photo with constellation backdrop"
    ],
    idealFor: "Families, School Groups, First-Timers",
    bonus: "Kids receive a 'Junior Stargazer' certificate"
  }
};

// Tab Display Logic
function showPlanet(key) {
  const data = tours[key];
  if (!data) return;

  const isLoggedIn = !!localStorage.getItem("userEmail");
  let price = data.price;

  // Apply discount for logged-in users
  if (isLoggedIn) {
    if (key === "dark-sky") price = "₹999 per person";
    if (key === "mountain-milky") price = "₹2,499 per person";
    if (key === "family-night") price = "₹699/adult, ₹399/child (under 12)";
  }

  document.getElementById("planet").innerHTML = `
    <h2>${data.title}</h2>
    <p><strong>Location:</strong> ${data.location}</p>
    <p><strong>Duration:</strong> ${data.duration}</p>
    <p><strong>Timings:</strong> ${data.timings}</p>
    <p><strong>Price:</strong> ${price}</p>
    <p><strong>Highlights:</strong></p>
    <ul>
      ${data.highlights.map(item => `<li>${item}</li>`).join("")}
    </ul>
    <p><br><strong>Ideal For:</strong> ${data.idealFor}</p>
    <p><strong>Bonus:</strong> ${data.bonus}</p>
  `;
}


// Initialize a tour on page load
document.addEventListener('DOMContentLoaded', () => {
  showPlanet('dark-sky'); // Show default tour
});

// Lightbox Logic
function openLightbox(img) {
  document.getElementById("lightbox-img").src = img.src;
  document.getElementById("lightbox").style.display = "flex";
}

function closeLightbox() {
  document.getElementById("lightbox").style.display = "none";
}

// Form Validation
function validateForm() {
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();

  if (!name || !email || !message) {
    alert("Please fill in all fields.");
    return false;
  }

  alert("Message sent successfully!");
  return false; // Prevents actual form submission
}